for the stage 2 output, if a word appeared in less than 5 bigrams, the bigrams they appear in are listed, along with null columns to add padding. 
